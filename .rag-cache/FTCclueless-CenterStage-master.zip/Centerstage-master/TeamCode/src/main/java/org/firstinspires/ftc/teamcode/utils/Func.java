package org.firstinspires.ftc.teamcode.utils;

public interface Func {
    Object call();
}
