package org.firstinspires.ftc.teamcode.utils;

public enum RunMode {
    TELEOP,
    AUTO,
    TESTER
}
