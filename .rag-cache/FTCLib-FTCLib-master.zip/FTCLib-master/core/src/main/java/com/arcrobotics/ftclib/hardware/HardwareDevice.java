package com.arcrobotics.ftclib.hardware;

public interface HardwareDevice {

    void disable();

    String getDeviceType();

}
