package com.arcrobotics.ftclib.util;

public enum Direction {
    LEFT, RIGHT, UP, DOWN, FORWARD, BACKWARDS
}
