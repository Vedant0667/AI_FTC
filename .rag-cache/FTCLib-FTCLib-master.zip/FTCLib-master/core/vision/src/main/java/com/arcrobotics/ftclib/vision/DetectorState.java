package com.arcrobotics.ftclib.vision;

public enum DetectorState {
    NOT_CONFIGURED,
    INITIALIZING,
    RUNNING,
    INIT_FAILURE_NOT_RUNNING;
}
