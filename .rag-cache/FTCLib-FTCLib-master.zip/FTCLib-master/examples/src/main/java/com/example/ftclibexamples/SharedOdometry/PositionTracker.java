package com.example.ftclibexamples.SharedOdometry;

import com.arcrobotics.ftclib.geometry.Pose2d;

public class PositionTracker {

    public static Pose2d robotPose;

}
