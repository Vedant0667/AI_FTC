package org.firstinspires.ftc.teamcode.opmodes;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

public class DriveHW extends LinearOpMode{
    @Override
    public void runOpMode() throws InterruptedException {
        // create 4 motors, leftFront, leftRear, rightFront, rightRear
        // read the PriorityMotor class if you don't know how to make one
        // remember hardware map exists :3

        // init

        // going to need a while loop for updating
        // use the left and right joysticks
        // left is for magnitude of power applied
        // right is for turning
    }
}
